import Vue from 'vue';
import './index.css';

new Vue({
	el:'#app',
	data:{
		message:'test success'
	}
})
